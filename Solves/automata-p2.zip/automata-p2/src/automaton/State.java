package automaton;

public interface State {
	public boolean initial();

	public boolean terminal();
}