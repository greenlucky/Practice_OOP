package Part_1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.event.MouseInputListener;

import machine.ChangeTransition;
import machine.ObservableAutomaton;
import machine.State;
import machine.StateImpl;
import machine.Transition;
import machine.TransitionImpl;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

public class GraphComponent extends JComponent implements MouseInputListener, KeyListener {

	private static final long serialVersionUID = 1L;
	private List<Shape> listPoints = new ArrayList<Shape>();
	private List<Edge> listLine = new ArrayList<Edge>();
	private ArrayList<Shape> tempEdge = new ArrayList<Shape>();
	private static int radius = 30;
	private int dx = 0;
	private int dy = 0;
	private int startState = 0;
	private ArrayList<Integer> endState;

	// index of circle have been clicked or dragged
	private int currently = -1;
	private int currentJoinPoint = -1;
	private int currentLine = -1;
	private int currentlyMove = -1;
	private boolean altPressed = false;
	private boolean spacePressed = false;
	private boolean movableJoinPoint = false;

	private Point2D sourcePoint;
	private Point2D desPoint;
	
	// current button to draw Rectangles or Circles or Squares
	private String currentButton = null;
	private ArrayList<State> states = new ArrayList<State>();
	ArrayList<Transition<String>> transitions = new ArrayList<Transition<String>>();
	

	public GraphComponent(int size) {
		setPreferredSize(new Dimension(size, size));

		setFocusable(true);

		// trigger mouser listener
		addMouseListener(this);
		// trigger event move mouse
		addMouseMotionListener(this);

		addKeyListener(this);

		new Point2D.Float();
		desPoint = new Point2D.Float();
		endState = new ArrayList<Integer>();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		pain(g);
	};

	protected void pain(Graphics g) {
		Font font = new Font("Serif", Font.BOLD, 20);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setFont(font);
		FontMetrics fm = g2d.getFontMetrics(font);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		// draw shape
		Iterator<Shape> listIterator = listPoints.iterator();
		int labelCount = 0;
		while (listIterator.hasNext()) {
			String labelNumber = Integer.toString(labelCount);
			Shape p = listIterator.next();
			int internalRadius = p.getRadius();
			int height = internalRadius * 2, width = internalRadius * 2;

			g2d.setColor(Color.BLUE);
			
			Ellipse2D ellipse = new Ellipse2D.Double((int) p.getPoint().getX() - internalRadius,
					(int) p.getPoint().getY() - internalRadius, width, height);
			
			if(labelCount == startState)
				g2d.setColor(Color.RED);
			
			if(endState.contains(labelCount))
				g2d.setColor(Color.BLACK);
			
			g2d.fill(ellipse);

			int widthLable = fm.stringWidth(labelNumber);

			// center String/text
			int cx = ((int) p.getPoint().getX() - widthLable / 2);
			int cy = ((int) p.getPoint().getY() + fm.getHeight() / 4);
			g2d.setColor(Color.white);
			g2d.drawString(labelNumber, cx, cy);
			labelCount++;
		}

		// draw line
		Iterator<Edge> iteLine = listLine.iterator();
		while (iteLine.hasNext()) {
			Edge linePoint = iteLine.next();
			Point2D source = listPoints.get(linePoint.getSource()).getPointClick();
			Point2D des = listPoints.get(linePoint.getDestination()).getPointClick();
			String label = linePoint.getLabel();

			createArrowLabel(g2d, label, source, des, linePoint.getType());
			g2d.setColor(Color.BLACK);
			g2d.draw(createArrowShape(source, des, linePoint.getType()));
			drawEdge(source, des, g2d , linePoint.getType());
		}
		
		// draw line while mouse move
		if (currently > -1) {
			if ((altPressed)) {
				drawEdge(sourcePoint, desPoint, g2d, currentButton);
				drawCircleLineSelect(sourcePoint, desPoint, g2d);
			}
		}
		
		//show select line
		lineSelect(g2d);
		
		print();
	}

	private void drawEdge(Point2D source, Point2D des, Graphics2D g2d , String type) {

		g2d.setColor(Color.BLACK);
		if(type=="art")
			createArc(g2d, source, des);
		else{
			Line2D line = new Line2D.Float(source, des);
			g2d.draw(line);
		}
	}
	
	private void lineSelect(Graphics2D g2d) {
		if(currentLine > -1){
			Point2D source = listPoints.get(listLine.get(currentLine).getSource()).getPoint();
			Point2D des = listPoints.get(listLine.get(currentLine).getDestination()).getPoint();
			drawCircleLineSelect(source, des, g2d);
		}
	}
	
	private void drawCircleLineSelect(Point2D source, Point2D des, Graphics2D g2d){
		g2d.setColor(Color.YELLOW);
		Ellipse2D cirSource = new Ellipse2D.Double(source.getX() - 5, source.getY() - 5, 10, 10);
		g2d.fill(cirSource);
		Ellipse2D cirDes = new Ellipse2D.Double(des.getX() - 5, des.getY() - 5, 10, 10);
		g2d.fill(cirDes);
	}

	public boolean checkPointIsCircle(MouseEvent e) {

		Iterator<Shape> listIterator = listPoints.iterator();
		int index = 0;
		while (listIterator.hasNext()) {
			
			Shape p = listIterator.next();
			boolean founded = false;
			if (((Ellipse2D) p.getBounds()).contains(e.getPoint())) {
				founded = true;
			}
			if (founded) {
				currently = index;
				return true;
			}
			index++;
		}
		return false;
	}

	public boolean checkPointIsCircle(Point2D point) {

		Iterator<Shape> listIterator = listPoints.iterator();
		int index = 0;
		while (listIterator.hasNext()) {
			Shape p = listIterator.next();
			if (((Ellipse2D) p.getBounds()).contains(point)) {
				currentlyMove = index;
				return true;
			}
			index++;
		}
		return false;
	}

	public boolean findPointInLine(MouseEvent e) {

		Iterator<Edge> edges = listLine.iterator();
		int index = 0;
		while (edges.hasNext()) {
			currentLine = index;
			Edge edge = edges.next();
			if (isJoinPoint(edge.getJoinPoint(), e.getPoint())) {
				return true;
			}
			index++;
		}
		return false;
	}
	
	private boolean findLine(MouseEvent e){
		Iterator<Edge> edges = listLine.iterator();
		int index = 0;
		while (edges.hasNext()) {
			Edge edge = edges.next();
			Line2D line = new Line2D.Float(listPoints.get(edge.getSource()).getPoint(),listPoints.get(edge.getDestination()).getPoint());
			if (line.ptSegDist(e.getPoint()) <= 2.0){
				currentLine = index;
				return true;
			}
			index++;
		}
		return false;
	}
	private boolean isJoinPoint(ArrayList<Shape> joinPoits, Point2D point) {
		Iterator<Shape> jpIter = joinPoits.iterator();
		int index = 0;
		while (jpIter.hasNext()) {
			currentJoinPoint = index;
			Shape sh = jpIter.next();
			if (((Ellipse2D) sh.getBounds()).contains(point)) {
				return true;
			}
			index++;
		}
		return false;
	}

	private void drawShape(int x, int y) {
		addShape(x, y);
		currently = listPoints.size() - 1;
		boolean st = false;
		boolean et = false;
		if(currently == startState)
			st = true;
		states.add(new StateImpl(st, et));
	}

	private void addShape(int x, int y) {

		Shape newShape = new Shape("state", new Point(x, y), radius);

		listPoints.add(newShape);
	}

	public void setCurrentButton(String currentButton) {
		this.currentButton = currentButton;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		requestFocusInWindow();
		currently = -1;
		currentLine = -1;
		
		if (checkPointIsCircle(e)) {
			dx = e.getX() - (int) listPoints.get(currently).getPoint().getX();
			dy = e.getY() - (int) listPoints.get(currently).getPoint().getY();
			sourcePoint = e.getPoint();
		}else if(findLine(e)){
			repaint();
		}
		
		if (e.getButton() == MouseEvent.BUTTON1) {

			if (currentButton == "state") {
				e.getPoint();
				int x = e.getX();
				int y = e.getY();
				drawShape(x, y);
				repaint();
			}
		}
		
		if (e.getButton() == MouseEvent.BUTTON3) {
			if(currently > -1 || currentLine > -1){
				showPopup(e);
			}else{
				currentButton = null;
			}
				
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		if (e.getButton() == MouseEvent.BUTTON3) {
			if(currently > -1 || currentLine > -1){
				showPopup(e);
			}else{
				currentButton = null;
			}	
		}
		
		if (e.getButton() == MouseEvent.BUTTON1) {
			if (currently > -1 && (currentButton == "line" || currentButton == "art")) {
				
				// add label for line
				String label = JOptionPane.showInputDialog(this, "Enter Label", "Enter Label",
						JOptionPane.OK_OPTION | JOptionPane.INFORMATION_MESSAGE);
				
				if (label != null && label != "") {
					
					if (!checkPointIsCircle(desPoint)) {
						e.getPoint();
						int x = e.getX();
						int y = e.getY();
		
						addShape(x, y);
		
						currentlyMove = listPoints.size() - 1;
						listPoints.get(currentlyMove).setDxy(0, 0);
					} 
					
					listLine.add(new Edge(currently, currentlyMove, tempEdge, label, currentButton));
					transitions.add(new TransitionImpl<String>(states.get(currently), states.get(currentlyMove), label));
					
					listPoints.get(currently).setHaveLine(true);
					listPoints.get(currently).setMovable(spacePressed);
					listPoints.get(currently).setLineIndex(currentLine);
					listPoints.get(currentlyMove).setHaveLine(true);
					listPoints.get(currentlyMove).setMovable(spacePressed);
				}
				currentButton = null;
				repaint();
			}
		}
		movableJoinPoint = false;
		altPressed = false;
		tempEdge.clear();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		altPressed = false;
		int x = e.getX();
		int y = e.getY();

		if (currently > -1) {
			if (currentButton == "line" || currentButton == "art") {
				desPoint = e.getPoint();
				altPressed = true;
			} else {
				listPoints.get(currently).getPoint().setLocation(x - dx, y - dy);
			}
		}
		if (movableJoinPoint) {
			listLine.get(currentLine).getEdge(currentJoinPoint).getPoint().setLocation(x - dx, y - dy);
		}

		repaint();
	}
	
	private void print(){
		Iterator<State> is = states.iterator();

		while(is.hasNext()){
			StateImpl state = (StateImpl) is.next();
			state.print();
		}
		Iterator<Transition<String>> it = transitions.iterator();
		while(it.hasNext()){
			TransitionImpl<String> transition = (TransitionImpl<String>) it.next();
			transition.print();
		}
		System.out.println(transitions.toString());
	}

	@Override
	public void keyPressed(KeyEvent e) {

		if (e.isAltDown()) {
			altPressed = true;
			if (e.getKeyCode() == KeyEvent.VK_SPACE)
				tempEdge.add(new Shape("circle", desPoint, 5));
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (!e.isAltDown()) {
			altPressed = false;
		}
	}

	public static java.awt.Shape createArrowShape(Point2D fromPt, Point2D toPt, String type) {
		Polygon arrowPolygon = new Polygon();
		// arrowPolygon.addPoint(-6,1);
		arrowPolygon.addPoint(3, 0);
		arrowPolygon.addPoint(0, 3);
		arrowPolygon.addPoint(3, 0);
		arrowPolygon.addPoint(0, -3);
		arrowPolygon.addPoint(3, 0);
		// arrowPolygon.addPoint(-6,-1);

		Point2D midPoint = midpoint(fromPt, toPt);
		
		int dxy = 0;
		if(type=="art")
			dxy = radius;
		
		double rotate = Math.atan2(toPt.getY() - fromPt.getY(), toPt.getX() - fromPt.getX());

		AffineTransform transform = new AffineTransform();
		
		transform.translate(midPoint.getX() - dxy , midPoint.getY() - dxy);
		double scale = 3; // 12 because it's the length of the arrow polygon.
		transform.scale(scale, scale);
		transform.rotate(rotate);

		return transform.createTransformedShape(arrowPolygon);
	}

	public static void createArrowLabel(Graphics2D g2d, String label, Point2D fromPt, Point2D toPt, String type) {
		AffineTransform oldXForm = g2d.getTransform();

		Point2D midPoint = midpoint(fromPt, toPt);

		double rotate = Math.atan2(toPt.getY() - fromPt.getY(), toPt.getX() - fromPt.getX());

		AffineTransform transform = new AffineTransform();
		transform.translate(midPoint.getX() - radius, midPoint.getY() - radius);
		transform.rotate(rotate);
		g2d.setColor(Color.BLUE);
		g2d.setTransform(transform);
		g2d.drawString(label, -10, -10);
		g2d.setTransform(oldXForm);

	}

	public static void createArc(Graphics2D g2d, Point2D fromPt, Point2D toPt) {

		AffineTransform oldXForm = g2d.getTransform();

		double rotate = Math.atan2(toPt.getY() - fromPt.getY(), toPt.getX() - fromPt.getX());

		int width = (int) fromPt.distance(toPt);
		int height = radius*2;
		int x = (int) fromPt.getX();
		int y = (int) fromPt.getY() - radius;
		if(fromPt.equals(toPt)){
			width = radius*3/2;
			height = 150;
			x -= radius - 5;
			y -= radius;
		}
		System.out.println("rotate: "+ rotate);
		/*
		 * to draw an arc in an applet window use, void drawArc(int x1,int y1,
		 * int width, int height,int startAngle, int arcAngle) method.
		 *
		 * This method draws an arc of specified width and height at (x1,y1)
		 */
		AffineTransform transform = new AffineTransform();
		transform.rotate(rotate, fromPt.getX(), fromPt.getY());
		g2d.setTransform(transform);
		g2d.drawArc(x, y, width, height, 15, 180);
		//g2d.draw(new Rectangle2D.Double(x, y, width, height));
		g2d.setTransform(oldXForm);
	}

	private static Point2D midpoint(Point2D fromPt, Point2D toPt) {
		return new Point2D.Double(fromPt.getX() + (toPt.getX() - fromPt.getX()) / 2,
				fromPt.getY() + (toPt.getY() - fromPt.getY()) / 2);
	}
	
	public void popupMenu(JPopupMenu popup){
		
        // New project menu item
        JMenuItem menuItem = new JMenuItem("Delete");
        menuItem.setMnemonic(KeyEvent.VK_P);
        menuItem.getAccessibleContext().setAccessibleDescription("Delete");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	//listLine.get(currentLine).removeEdge(currentJoinPoint);
				//repaint();
				if (currentLine > -1) {
					listPoints.get(currentLine).setHaveLine(false);
					listPoints.get(currentLine).setLineIndex(-1);
					listLine.remove(currentLine);
					transitions.remove(currentLine);
					
					currentLine = -1;
					
				} else {
					if(listPoints.get(currently).getLineIndex() > -1){
						listLine.remove(listPoints.get(currently).getLineIndex());
						transitions.remove(listPoints.get(currently).getLineIndex());
					}
					listPoints.remove(currently);
					//remove state
					states.remove(currentLine);
				}
				currentLine = -1;
				repaint();
            }
        });
        popup.add(menuItem);
        
        //show menu start and end state when select state
        if(currentLine == -1){
	        // New File menu item
	        menuItem = new JMenuItem("Start");
	        menuItem.setMnemonic(KeyEvent.VK_F);
	        menuItem.addActionListener(new ActionListener() {
	
	            public void actionPerformed(ActionEvent e) {
	            	//remove start of current state
	            	states.get(startState).setInitial(false);
	                startState = currently;
	                //set start state for new state
	                states.get(currently).setInitial(true);
	                repaint();
	            }
	        });
	        popup.add(menuItem);
	        
	        // New File menu item
	        menuItem = new JMenuItem("End");
	        menuItem.setMnemonic(KeyEvent.VK_F);
	        menuItem.addActionListener(new ActionListener() {
	        	
	        	public void actionPerformed(ActionEvent e) {
	        		if(!endState.contains(currently))
	        			endState.add(currently);
	        		states.get(currently).setTerminal(true);
	        		repaint();
	        	}
	        });
	        popup.add(menuItem);
	        
	        // New File menu item
	        menuItem = new JMenuItem("Normal State");
	        menuItem.setMnemonic(KeyEvent.VK_F);
	        menuItem.addActionListener(new ActionListener() {
	        	
	        	public void actionPerformed(ActionEvent e) {
	        		if(endState.contains(currently))
	        			endState.remove(endState.indexOf(currently));
	        		states.get(currently).setTerminal(false);
	        		repaint();
	        	}
	        });
	        popup.add(menuItem);
        }
	}
	
	public void recognizeWords(String words){
		String[] word = words.split("");
		ChangeTransition ct = new ChangeTransition();
		
		try {
			ObservableAutomaton<String> obs = new ObservableAutomaton<String>(transitions);
			obs.addObserver(ct);
			obs.recognize(word);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void showPopup(MouseEvent e) {
		System.out.println(e.isPopupTrigger());
        if (e.isPopupTrigger()) {
        	JPopupMenu popup = new JPopupMenu();
        	popupMenu(popup);
            popup.show(e.getComponent(),
                    e.getX(), e.getY());
        }
    }
	
	public void mouseClicked(MouseEvent e) {}
	
	public void mouseEntered(MouseEvent e) {}
	
	public void mouseExited(MouseEvent e) {}
	
	public void mouseMoved(MouseEvent e) {}

	public void move(Graphics g) {}
	
	public void keyTyped(KeyEvent arg0) {}
}
