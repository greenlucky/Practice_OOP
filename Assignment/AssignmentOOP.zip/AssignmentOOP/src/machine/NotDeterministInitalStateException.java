package machine;

public class NotDeterministInitalStateException extends Exception{

	public NotDeterministInitalStateException(String msg){
		super(msg);
	}
}
