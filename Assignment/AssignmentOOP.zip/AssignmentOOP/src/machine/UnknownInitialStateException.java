package machine;

public class UnknownInitialStateException extends Exception{
	public UnknownInitialStateException(String msg){
		super(msg);
	}
}
