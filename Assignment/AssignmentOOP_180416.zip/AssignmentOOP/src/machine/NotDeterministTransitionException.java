package machine;

class NotDeterministTransitionException extends Exception{
		
	public NotDeterministTransitionException(String msg){
		super(msg);
	}

}
