package machine;

public class TransitionImpl<T> implements Transition{
	
	private State source;
	private State target;
	private T label;
	
	public TransitionImpl(State source, State target, T label) {
		
		this.source = source;
		this.target = target;
		this.label = label;
	}

	@Override
	public State source() {
		// TODO Auto-generated method stub
		return source;
	}

	@Override
	public State target() {
		// TODO Auto-generated method stub
		return target;
	}

	@Override
	public T label() {
		// TODO Auto-generated method stub
		return label;
	}
	
	public void print(){
		System.out.println("Source "+ source + ", target "+ target + ", Lable"+ label);
	}

}
