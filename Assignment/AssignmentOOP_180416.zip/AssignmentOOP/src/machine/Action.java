package machine;

public interface Action<T> {
	public void excute(T arg);
}
