package Part_1;

import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

public class Edge {
	
	//source and destination is index of shape in list shape
	private String type;
	private String label;
	private int source;
	private int destination;
	private boolean movable;
	private Point2D ctrl1;
	private Point2D ctrl2;

	Edge(int source, int destination, String label, String type){
		this.source = source;
		this.destination = destination; 
		this.label = label;
		this.type = type;
		ctrl1 = new Point2D.Float();
		ctrl2 = new Point2D.Float();
	}
	
	Edge(int source, int destination, String label, String type, Point2D ctrl1,  Point2D ctrl2){
		this.source = source;
		this.destination = destination; 
		this.label = label;
		this.type = type;
		this.ctrl1 = ctrl1;
		this.ctrl2 = ctrl2;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	Edge(int source, int destination, boolean movable){
		this.source = source;
		this.destination = destination; 
		this.movable = movable;
	}
	
	public boolean isMovable() {
		return movable;
	}
	
	public int getSource() {
		return source;
	}

	public void setSource(int source) {
		this.source = source;
	}

	public int getDestination() {
		return destination;
	}

	public void setDestination(int destination) {
		this.destination = destination;
	}

	public Point2D getCtrl1() {
		return ctrl1;
	}

	public void setCtrl1(Point2D ctrl1) {
		this.ctrl1 = ctrl1;
	}

	public Point2D getCtrl2() {
		return ctrl2;
	}

	public void setCtrl2(Point2D ctrl2) {
		this.ctrl2 = ctrl2;
	}
	
	public boolean isAnchorCtrl(MouseEvent e, int type){
		if(type==1)
			return (new Ellipse2D.Float((int)ctrl1.getX()- 5,(int)ctrl1.getY() - 5, 10, 10).contains(e.getPoint()));
		else
			return (new Ellipse2D.Float((int)ctrl2.getX()- 5,(int)ctrl2.getY() - 5, 10, 10).contains(e.getPoint()));
	}
}
