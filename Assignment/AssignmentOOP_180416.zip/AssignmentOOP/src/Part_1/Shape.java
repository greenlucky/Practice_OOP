package Part_1;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

public class Shape {
	private String type;
	private Point2D point;
	private boolean haveLine;
	private boolean movable;
	private int lineIndex;
	private int radius;
			
	public Shape(String type, Point2D point, int radius) {
		this.type = type;
		this.point = point;
		this.radius = radius;
		haveLine = false;
		lineIndex = -1;
	}

	public int getLineIndex() {
		return lineIndex;
	}

	public void setLineIndex(int lineIndex) {
		this.lineIndex = lineIndex;
	}

	public boolean isMovable() {
		return movable;
	}

	public void setMovable(boolean movable) {
		this.movable = movable;
	}

	public boolean isHaveLine() {
		return haveLine;
	}

	public void setHaveLine(boolean haveLine) {
		this.haveLine = haveLine;
	}
	
	public Point2D getPointClick(){
		return new Point2D.Double(point.getX(), point.getY());
	}
	
	public void setRadius(int radius){
		this.radius = radius;
	}
	
	public int getRadius(){
		return radius;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public Point2D getPoint() {
		return point;
	}
	
	public void setPoint(Point2D point) {
		this.point = point;
	}

	public void add(Shape newShape) {
		this.type = newShape.getType();
		this.point = newShape.getPoint();
	}
	
	public Object getBounds(){
		if(this.type=="line"){
			return new Ellipse2D.Double(point.getX() - radius, point.getY() - radius, radius*2, radius*2);
		}
		return new Ellipse2D.Double(point.getX() - radius, point.getY() - radius, radius*2, radius*2);
	}
		
}
